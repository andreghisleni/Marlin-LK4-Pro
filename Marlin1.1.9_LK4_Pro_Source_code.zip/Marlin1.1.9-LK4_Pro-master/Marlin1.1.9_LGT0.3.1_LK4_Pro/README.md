# LK4_Pro 3D Printer Firmware
## Marlin1.1.9 LGT0.3.1
This firmware was modified by Longer3D. It was based on Marlin 1.1.9 and applies to LK4_Pro.

